<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>307 Temporary Redirect</title>
</head><body>
<h1>Temporary Redirect</h1>
<p>The document has moved <a href="https://mirrors.mit.edu/CTAN/systems/texlive/tlnet/update-tlmgr-latest.sh">here</a>.</p>
</body></html>
